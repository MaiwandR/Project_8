import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../client';


export default function Edit() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [crewmate, setCrewmate] = useState({
        name: '',
        speed: 0,
        color: ''
    });

    useEffect(() => {
        async function fetchData() {
            const { data } = await supabase.from('crewmates').select().eq('id', id).single();
            setCrewmate(data);
        }
        fetchData();
    }, [id]);

    const handleChange = (e) => {
        setCrewmate({ ...crewmate, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await supabase.from('crewmates').update(crewmate).eq('id', id);
        navigate(`/crewmate/${id}`);
    };

    return (
        <div>
            <h1>Edit Crewmate</h1>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" value={crewmate.name} onChange={handleChange} placeholder="Name" />
                <input type="number" name="speed" value={crewmate.speed} onChange={handleChange} placeholder="Speed" />
                <input type="text" name="color" value={crewmate.color} onChange={handleChange} placeholder="Color" />
                <button type="submit">Save</button>
            </form>
        </div>
    );
}