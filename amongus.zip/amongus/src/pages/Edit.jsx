import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '../client.jsx';
import pic from '../assets/pic.png';


export default function Edit() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [crewmate, setCrewmate] = useState({
        name: '',
        speed: 0,
        color: ''
    });

    useEffect(() => {
        async function fetchData() {
            const { data } = await supabase.from('crewmates').select().eq('id', id).single();
            setCrewmate(data);
        }
        fetchData();
    }, [id]);

    const handleChange = (e) => {
        setCrewmate({ ...crewmate, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        await supabase.from('crewmates').update({name: crewmate.name, speed: crewmate.speed, color: crewmate.color}).eq('id', id);
        navigate(`/crewmate/${id}`);
    };

    return (
        <div>
           
            
            <form className='editForm' onSubmit={handleSubmit}>
            <h1>Edit Crewmate</h1>
            <img className='pic' src={pic} alt="Crewmate" />
                <input type="text" name="name" value={crewmate.name} onChange={handleChange} placeholder="Name" />
                <input type="number" name="speed" value={crewmate.speed} onChange={handleChange} placeholder="Speed" />
                <select name='color' id="colors" value={crewmate.color} onChange={handleChange} >
                    <option value="red">Red</option>
                    <option value="blue">Blue</option>
                    <option value="green">Green</option>
                    <option value="yellow">Yellow</option>
                    <option value="purple">Purple</option>
                    <option value="orange">Orange</option>
                    <option value="pink">Pink</option>
                    <option value="black">Black</option>
                    <option value="white">White</option>
                </select>
                <button type="submit">Save</button>
            </form>
        </div>
    );
}