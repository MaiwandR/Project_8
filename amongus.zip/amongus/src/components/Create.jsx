import { useState } from 'react';
import { supabase } from '../client';
import { useNavigate } from 'react-router-dom';


const Create = () => {

    const [name, setName] = useState('');
    const [color, setColor] = useState('');
    const [speed, setSpeed] = useState(0);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        await supabase.from('crewmates').insert({ name, color, speed });
        navigate('/');
    };


    return (

        <>

            <form onSubmit={handleSubmit}>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder='Name' required/>
                <input type="number" value={speed} onChange={(e) => setSpeed(e.target.value)} placeholder='Speed' required/>
                <select id="colors" value={color} onChange={(e) => setColor(e.target.value)}>
                    <option value="red">Red</option>
                    <option value="blue">Blue</option>
                    <option value="green">Green</option>
                    <option value="yellow">Yellow</option>
                    <option value="purple">Purple</option>
                    <option value="orange">Orange</option>
                    <option value="pink">Pink</option>
                    <option value="black">Black</option>
                    <option value="white">White</option>
                </select>
                
                <button type='submit'>Add Crewmate</button>
            
            </form>    
        
        </>

    )
}