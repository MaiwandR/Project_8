import { useState } from 'react';
import { supabase } from '../client.jsx';
import { useNavigate } from 'react-router-dom';
import pic from '../assets/pic.png';
import group from '../assets/group.png';


const Create = () => {

    const [name, setName] = useState('');
    const [color, setColor] = useState('');
    const [speed, setSpeed] = useState(0);
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        await supabase.from('crewmates').insert({ name: name, color: color, speed: speed }).select();
        navigate('/');
    };


    return (

        <div className='createPage'>

            <form className='createForm'>
                <img className='pic' src={pic} alt="" />
                <h2>Create your own Crewmate!</h2>
                <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder='Name' required/>
                <input type="number" value={speed} onChange={(e) => setSpeed(e.target.value)} placeholder='Speed' required/>
                <select id="colors" value={color} onChange={(e) => setColor(e.target.value)}>
                    <option value="red">Red</option>
                    <option value="blue">Blue</option>
                    <option value="green">Green</option>
                    <option value="yellow">Yellow</option>
                    <option value="purple">Purple</option>
                    <option value="orange">Orange</option>
                    <option value="pink">Pink</option>
                    <option value="black">Black</option>
                    <option value="white">White</option>
                </select>
                
                <input type="submit" value='Submit' onClick={handleSubmit} />
            
            </form>    
        
        </div>

    )
}

export default Create;