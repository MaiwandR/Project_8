import { useEffect, useState } from 'react';
import { supabase } from '../client';
import { Link } from 'react-router-dom';
import pic from '../assets/pic.png';


const DisplayAll = () => {
    const [crewmates, setCrewmates] = useState([]);

    useEffect(() => {
        async function getCrewmates() {
          const { data } = await supabase
            .from('crewmates')
            .select()
            .order('created_at', { ascending: false });
          setCrewmates(data);
        }
        getCrewmates();
      }, []);


    return(
        <div>
            <Link to={'/create'}>Add a New Crewmate!</Link>
            {crewmates.length === 0 ? (
                <p>No Crewmates Found</p>
                ) : (
                <div className='crewmate-gallery'>
                    {crewmates.map((crewmate) => (
                    <div className='crewmate-card' key={crewmate.id}>
                        {/* <img src={pic} alt="Crewmate" /> */}
                        <h2>{crewmate.name}</h2>
                        <p>Speed: {crewmate.speed}</p>
                        <p>Color: {crewmate.color}</p>
                        <Link to={`/edit/${crewmate.id}`}>Edit</Link>
                    </div>
                    ))}
                </div>
                )}

        </div>
        

    )

}


export default DisplayAll;