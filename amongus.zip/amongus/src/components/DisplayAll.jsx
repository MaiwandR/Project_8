import { useEffect, useState } from 'react';
import { supabase } from '../client.jsx';
import { Link } from 'react-router-dom';
import pic from '../assets/pic.png';

const DisplayAll = () => {
  const [crewmates, setCrewmates] = useState([]);

  useEffect(() => {
    async function getCrewmates() {
      const { data } = await supabase
        .from('crewmates')
        .select()
        .order('created_at', { ascending: false });
      setCrewmates(data);
    }
    getCrewmates();
  }, []); // <-- FIXED THIS!

  const handleDelete = async (id) => {
    await supabase.from('crewmates').delete().eq('id', id);
    setCrewmates((prev) => prev.filter((crewmate) => crewmate.id !== id));
  };

  return (
    <div>
      <h1>Crewmate Gallery</h1>
      {crewmates.length === 0 ? (
        <p>No Crewmates Found</p>
      ) : (
        <div className='crewmate-gallery'>
          {crewmates.map((crewmate) => (
            <div
              className='crewmate-card'
              key={crewmate.id}
              style={{
                boxShadow: `5px 5px 10px ${"light" + crewmate.color}`,
                border: `2px solid ${crewmate.color}`,
              }}
            >
              <img src={pic} alt="Crewmate" />
              <Link to={`/crewmate/${crewmate.id}`}>
              <h2 style={{color: crewmate.color}}>{crewmate.name}</h2>
              </Link>
              <p>Speed: {crewmate.speed} mph</p>
              <p>Color: {crewmate.color}</p>
              <Link className='editor' to={`/edit/${crewmate.id}`} 
              style={{
                boxShadow: `5px 5px 10px ${"light" + crewmate.color}`,
                border: `2px solid ${crewmate.color}`,
              }}
              >Edit</Link>
              <button className='editor' onClick={() => handleDelete(crewmate.id)}
              style={{
                boxShadow: `5px 5px 10px ${"light" + crewmate.color}`,
                border: `2px solid ${crewmate.color}`,
                marginTop: '10px',
              }}
              >Delete</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DisplayAll;
