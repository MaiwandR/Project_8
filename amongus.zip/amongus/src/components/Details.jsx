import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../client.js';
import pic from '../assets/pic.png';



const Details = () => {
    
    const { id } = useParams();
    const [crewmate, setCrewmate] = useState(null);

    useEffect(() => {
        async function fetchData() {
          const { data } = await supabase.from('crewmates').select().eq('id', id).single();
          setCrewmate(data);
        }
        fetchData();
      }, [id]);

    if (!crewmate) {
        return <div>Loading...</div>;
    }

    return(
        <div>
            <h1>{crewmate.name}</h1>
            {/* <img src={pic} alt="Crewmate" /> */}
            <p>Speed: {crewmate.speed}</p>
            <p>Color: {crewmate.color}</p>

        </div>
    )
}

export default Details;