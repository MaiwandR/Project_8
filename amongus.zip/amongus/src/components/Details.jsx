import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../client.jsx';
import pic from '../assets/pic.png';



const Details = () => {
    
    const { id } = useParams();
    const [crewmate, setCrewmate] = useState(null);

    useEffect(() => {
        async function fetchData() {
          const { data } = await supabase.from('crewmates').select().eq('id', id).single();
          setCrewmate(data);
        }
        fetchData();
      }, [id]);

    if (!crewmate) {
        return <div>Loading...</div>;
    }

    return(
        <div className='detailPage' 
            style={{
                backgroundColor: crewmate.color,
            }}
        >
            <h1>{crewmate.name}</h1>
            <img src={pic} alt="Crewmate" />
            <h2>Stats:</h2>
            <p>Speed: {crewmate.speed} mph</p>
            <p>Color: {crewmate.color}</p>
            

        </div>
    )
}

export default Details;