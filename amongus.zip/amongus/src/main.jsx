import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

import Layout from './pages/Layout.jsx';
import App from './App.jsx';
import Create from './components/Create.jsx';
import DisplayAll from './components/displayAll.jsx';
import Details from './components/Details.jsx';
import Edit from './pages/Edit.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Layout />}>
          <Route index={true} element={<App />} />
          <Route path='/create' element={<Create />} />
          <Route path='/gallery' element={<DisplayAll />} />
          <Route path='/crewmate/:id' element={<Details />} />
          <Route path='/edit/:id' element={<Edit />} />
        </Route>
      </Routes>
    </BrowserRouter>
  </StrictMode>
);
