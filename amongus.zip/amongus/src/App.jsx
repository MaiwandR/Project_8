import { useState } from 'react'
import './App.css'
import group from './assets/group.png'
import ufo from './assets/ufo.webp'




// In App.jsx
const App = () => {
  return (
    <div className='home'>
      <h1>Welcome to Crewmate Creator!</h1>
      <p>Here is wher you can create your very own set of crewmates before sending them off into space!</p>
      <img src={group} alt="" className="group" />
      <img src={ufo} alt="" className="ufo" />
    </div>
  );
}

export default App;