import { useState } from 'react'
import './App.css'




// In App.jsx
const App = () => {
  return (
    <div>
      <h1>Hello from App!</h1>
    </div>
  );
}

export default App;