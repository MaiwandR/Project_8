import { createClient} from '@supabase/supabase-js';


const URL = 'https://bmdkfzssxexfpuacreun.supabase.co'
const API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtZGtmenNzeGV4ZnB1YWNyZXVuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUwMzIxNzIsImV4cCI6MjA2MDYwODE3Mn0.D-tGASPx9eRcVq1mIx4gwwJBCllwlBHPPjPqgi9qioo"


export const supabase = createClient(URL, API_KEY)